import java.awt.BorderLayout;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTree;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.UnsupportedLookAndFeelException;

import net.miginfocom.swing.MigLayout;

import java.awt.Panel;

import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.border.BevelBorder;
import javax.swing.JProgressBar;
import javax.swing.SwingConstants;

import java.awt.Font;

import javax.swing.border.EtchedBorder;
import javax.swing.JSlider;

public class Main {
	private static final JLabel lblLocation = new JLabel("Location");
	private static final JLabel lblImagePreview = new JLabel("");
	private static final JPanel panel_2 = new JPanel();
	private static final JMenuBar menuBar = new JMenuBar();
	private static final JMenu mnFile = new JMenu("File");
	private static final JMenuItem mntmOpen = new JMenuItem("Open");
	private static final JMenuItem mntmClear = new JMenuItem("Clear");
	private static final JTextField locationField = new JTextField();
	private static final JScrollPane scrollPanenew = new JScrollPane();


	private static final ImageIcon iconOpen = new ImageIcon("icons/open.png");
	private static final ImageIcon iconSave = new ImageIcon("icons/save.jpg");
	private static final ImageIcon iconLoad = new ImageIcon("icons/load.jpg");
	private static final ImageIcon iconClear = new ImageIcon("icons/Close.png");
	private static final ImageIcon iconPlus = new ImageIcon("icons/plus.png");
	private static final ImageIcon iconMinus = new ImageIcon("icons/minus.png");
	private static final ImageIcon iconHome = new ImageIcon("icons/home.png");
	private static final ImageIcon iconBack = new ImageIcon("icons/back.png");
	private static final ImageIcon iconForward = new ImageIcon("icons/forward.png");

	private static JSplitPane splitPane = new JSplitPane();

	
	private static final JLabel iconOpenP = new JLabel(iconOpen);
	private static final JLabel iconSaveP = new JLabel(iconSave);
	private static final JLabel iconLoadP = new JLabel(iconLoad);
	private static final JLabel iconClearP = new JLabel(iconClear);
	private static final JLabel iconPlusP = new JLabel(iconPlus);
	private static final JLabel iconMinusP = new JLabel(iconMinus);
	private static final JLabel iconHomeP = new JLabel(iconHome);
	private static final JLabel iconBackP = new JLabel(iconBack);
	private static final JLabel iconForwardP = new JLabel(iconForward);

	private static FileSystemModel fileSystemModel;
	private static JTextArea fileDetailsTextArea = new JTextArea();
	private static JTree tree = new JTree();
	static BufferedImage image = null;
	private static final JProgressBar progressBar = new JProgressBar();
	private static final JLabel lblLoadingImage = new JLabel("Loading Image");
	private static final JMenu mnView = new JMenu("View");
	private static final JMenu mnNewMenu = new JMenu("Go");
	private static final JMenu mnHelp = new JMenu("Help");
	private static final JMenu mnTag = new JMenu("Print");
	private static final JMenu mnFavourites = new JMenu("Favourites");
	private static final JMenu mnCreate = new JMenu("Slide Show");
	private static final JMenu mnTools = new JMenu("Tools");
	private static final JPanel panel_3 = new JPanel();
	private static final JPanel panel_4 = new JPanel();
	private static final JLabel imagePreview = new JLabel("Image Preview");
	private static final JPanel panel_5 = new JPanel();
	private static final JMenuItem mntmResolution = new JMenuItem("Resolution");
	private static final JMenuItem mntmEmail = new JMenuItem("Email");
	private static final JMenuItem mntmOpenWith = new JMenuItem("Open With");
	private static final JMenuItem mntmCopy = new JMenuItem("Copy");
	private static final JMenuItem mntmProperties = new JMenuItem("Properties");
	private static final JMenuItem mntmNewMenuItem = new JMenuItem("Print CTRL+P");
	private static final JMenuItem mntmOrderPrints = new JMenuItem("Order Prints");
	private static final JMenuItem mntmPlaySlideShow = new JMenuItem("Play Slide Show");
	private static final JSplitPane panel_1 = new JSplitPane();
	private static final JLabel preview = new JLabel("");
	private static final JSlider slider = new JSlider();
	private static final JMenuItem mntmOpenFavourites = new JMenuItem("Open Favourites");
	private static final JMenuItem mntmSelect = new JMenuItem("Select");
	private static final JMenuItem mntmZoomIn = new JMenuItem("Zoom In");
	private static final JMenuItem mntmZoomOut = new JMenuItem("Zoom Out");
	private static final JMenuItem mntmFullScreen = new JMenuItem("Full Screen");
	private static String filePath = null;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		UIManager.put("nimbusBase", Color.WHITE);
		UIManager.put("nimbusBlueGrey", Color.WHITE);
		UIManager.put("control", Color.WHITE);
		
		
		

		for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
			if ("Nimbus".equals(info.getName())) {
				try {
					UIManager.setLookAndFeel(info.getClassName());
				} catch (ClassNotFoundException | InstantiationException
						| IllegalAccessException
						| UnsupportedLookAndFeelException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}
		}
		locationField.setColumns(10);
		// TODO Auto-generated method stub
		JFrame frame = new JFrame("Image Viewer");
		JFrame frame2 = new JFrame("Full Scale Image");

		frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
		frame.setSize(1000, 500);
		frame.getContentPane().setLayout(new MigLayout("", "[grow][grow]", "[][][][grow]"));
		panel_4.setBackground(Color.WHITE);
		panel_4.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null,null, null));

		frame.getContentPane().add(panel_4, "cell 0 0 2 1,grow");
		panel_4.setLayout(new MigLayout("", "[grow]", "[]"));
		panel_3.setBackground(Color.WHITE);
		panel_4.add(panel_3, "cell 0 0,alignx left,growy");
		iconOpenP.setHorizontalAlignment(SwingConstants.LEFT);
		
	
		panel_3.add(iconOpenP);
		iconSaveP.setHorizontalAlignment(SwingConstants.LEFT);
		panel_3.add(iconSaveP);
		iconLoadP.setHorizontalAlignment(SwingConstants.LEFT);
		panel_3.add(iconLoadP);
		panel_3.add(iconMinusP);
		iconMinusP.setHorizontalAlignment(SwingConstants.LEFT);
		panel_3.add(iconPlusP);
		iconPlusP.setHorizontalAlignment(SwingConstants.LEFT);
		panel_3.add(iconHomeP);
		iconHomeP.setHorizontalAlignment(SwingConstants.LEFT);
		panel_3.add(iconBackP);
		iconBackP.setHorizontalAlignment(SwingConstants.LEFT);
		panel_3.add(iconForwardP);
		iconForwardP.setHorizontalAlignment(SwingConstants.LEFT);
	

		iconClearP.setHorizontalAlignment(SwingConstants.LEFT);
		panel_3.add(iconClearP);
		iconClearP.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent mAE) {
				preview.setIcon(null);
				progressBar.setValue(0);
				errorMsg("Clear Area ", "Clear");
				frame2.dispose();
				frame2.revalidate();
				frame2.repaint();

			}
		});

		iconLoadP.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent me) {
				
				frame.getContentPane().remove(splitPane);

				InputStream in = null;
				try {
					in = new FileInputStream(new File("out.txt"));
				} catch (FileNotFoundException e) {
					errorMsg(
							"Save file wasn't generated! Please save a location first to use this function!",
							"Load error");
					System.out
							.println("out.txt was not generated! save first before reading!!");
					e.printStackTrace();
				}
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(in));
				StringBuilder out = new StringBuilder();
				String line;
				try {
					while ((line = reader.readLine()) != null) {
						out.append(line);
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
				System.out.println("loading location" + out.toString());
				errorMsg("Location loaded.", "Load");
				locationField.setText(out.toString());

				fileDetailsTextArea.setEditable(false);
				fileSystemModel = new FileSystemModel(new File(out.toString()));
				tree = new JTree(fileSystemModel);
				tree.setEditable(true);
				tree.addTreeSelectionListener(new TreeSelectionListener() {
					public void valueChanged(TreeSelectionEvent event) {
						File file = (File) tree.getLastSelectedPathComponent();
						fileDetailsTextArea.setText(getFileDetails(file));
					}
				});

				scrollPanenew.setViewportView(tree);
				frame.getContentPane().add(scrollPanenew,"cell 0 2,alignx left,aligny top,growy");
				try {
					reader.close();
				} catch (IOException e) {
					errorMsg("couldn't close reader!", "Reader ERROR!");
					e.printStackTrace();
				}

			}
		});

		iconSaveP.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent me) {
				System.out.println("CLICKED save");

				String loc = locationField.getText();
				if (!locationField.getText().isEmpty()) {
					BufferedWriter out = null;
					try {
						FileWriter fstream = new FileWriter("out.txt"); 
						out = new BufferedWriter(fstream);
						out.write("\n" + loc);
						System.out.println("saved location!");
						errorMsg("Location Saved", "Save");
					} catch (IOException e) {
						System.err.println("Error: " + e.getMessage());
					} finally {
						if (out != null) {
							try {
								out.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					}

				} else {
					System.out.println("user didnt select a location!");
				}
			}
		});
		iconPlusP.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent me) {
				errorMsg("Increase Image", "Increase");
			}
		});
		iconMinusP.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent me) {
				errorMsg("Decrrease Image", "Decrease");
			}
		});
		iconOpenP.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent me) {

				int result;
				String choosertitle = null;

				JFileChooser chooser = new JFileChooser();
				chooser.setCurrentDirectory(new java.io.File("."));
				chooser.setDialogTitle(choosertitle);
				chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

				chooser.setAcceptAllFileFilterUsed(false);
				//
				if (chooser.showOpenDialog(menuBar) == JFileChooser.APPROVE_OPTION) {

					locationField.setText(chooser.getSelectedFile().toString());

					fileDetailsTextArea.setEditable(false);
					fileSystemModel = new FileSystemModel(new File(chooser.getSelectedFile().toString()));
					tree = new JTree(fileSystemModel);
					tree.setEditable(true);
					tree.addTreeSelectionListener(new TreeSelectionListener() {
						public void valueChanged(TreeSelectionEvent event) {

							Object object = event.getPath()
									.getLastPathComponent();
							if (object instanceof File) {
								File file = (File) object;
								//f2 = file;
								filePath = file.getAbsolutePath();
								System.out
										.println("FILEPATH" +filePath);

								if (file.toString().toLowerCase().endsWith(".jpg")|| file.toString().toLowerCase().endsWith(".png")) {
									BufferedImage image = null;
									try {
										image = ImageIO.read(file);

									} catch (Exception e1) {
										e1.printStackTrace();
										System.exit(1);
									}
									// Preview Image
									ImageIcon imageIcon = new ImageIcon(image);
									Image images = imageIcon.getImage();
									Image newimg = images.getScaledInstance(100, 100,java.awt.Image.SCALE_SMOOTH);

									imageIcon = new ImageIcon(newimg);
									preview.setIcon(imageIcon);
									frame.getContentPane().add(panel_1,"center,grow");

									tree.addMouseListener(new MouseAdapter() {
										public void mouseClicked(MouseEvent e) {
											if (e.getClickCount() == 2) {

												BufferedImage image = null;
												try {

													image = ImageIO.read(file);
													
													BufferedImage img = ImageIO.read(file);
													int width = img.getWidth();
													int height = img.getHeight();

													ImageIcon icon = new ImageIcon(img);
													Image images = icon.getImage();
													Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
													int screenWidth = (int) screenSize.getWidth();
													int screenHeight = (int) screenSize.getHeight();
											

													int newWidth;
													int newHight;
													if (width > screenWidth|| height > screenHeight) {

														if (height > screenHeight&& width < screenWidth) {

															Image newimg = images.getScaledInstance(width,screenHeight - 100,java.awt.Image.SCALE_SMOOTH);
															icon = new ImageIcon(newimg); // transform

														} 
														else if (height < screenHeight&& width > screenWidth) {

															Image newimg = images.getScaledInstance(screenWidth - 100,height,java.awt.Image.SCALE_SMOOTH);
															icon = new ImageIcon(newimg); // transform
																			
														} 
														else 
														{
															Image newimg = images.getScaledInstance(screenWidth - 100,screenHeight - 100,java.awt.Image.SCALE_SMOOTH);
															icon = new ImageIcon(newimg); 				
														}
													} else {
														Image newimg = images.getScaledInstance(width,height,java.awt.Image.SCALE_SMOOTH);											
														icon = new ImageIcon(newimg); 					
													}
													JFrame frame2 = new JFrame();
													frame2.getContentPane().setLayout(new MigLayout());
													JLabel lbl = new JLabel();
													lbl.setIcon(icon);
													frame2.getContentPane().add(lbl);
													frame2.setSize(frame2.getPreferredSize());
													progressBar.setValue(100);
													progressBar.setStringPainted(true);
													frame2.validate();
													frame2.repaint();
													frame2.setVisible(true);

												} catch (Exception e1) {
													e1.printStackTrace();
													System.exit(1);
												}
											}
										}
									});

								}
							}

						}

					});

					scrollPanenew.setViewportView(tree);

				} else {
					System.out.println("No Selection");
				}
			}
		});
		lblLocation.setBackground(Color.WHITE);
		frame.getContentPane().add(lblLocation,"flowx,cell 0 1,alignx left,sg a");
		frame.getContentPane().add(locationField, "cell 0 1,grow,sg a");
		panel_5.setBackground(Color.WHITE);
		panel_5.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null,null, null));

		frame.getContentPane().add(panel_5, "cell 1 1 1 2,grow");
		panel_5.setLayout(new MigLayout("", "[grow]", "[][]"));
		panel_5.add(imagePreview, "flowy,cell 0 0 1 2,alignx center");
		imagePreview.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblLoadingImage.setBackground(Color.WHITE);

		frame.getContentPane().add(lblLoadingImage, "flowx,cell 0 2,sg a");
		progressBar.setStringPainted(true);
		progressBar.setBackground(Color.WHITE);
		frame.getContentPane().add(progressBar, "cell 0 2,grow,sg a");
		scrollPanenew.setViewportBorder(new BevelBorder(BevelBorder.LOWERED,null, null, null, null));
		frame.getContentPane().add(scrollPanenew, "cell 0 3,alignx left,grow");
		panel_1.setBackground(Color.WHITE);
		frame.getContentPane().add(panel_1, "cell 1 3,grow");
		preview.setForeground(Color.WHITE);
		preview.setBackground(Color.WHITE);
		preview.setHorizontalAlignment(SwingConstants.CENTER);

		panel_1.setRightComponent(preview);
		slider.setBackground(Color.WHITE);
		slider.setForeground(Color.WHITE);
		slider.setOrientation(SwingConstants.VERTICAL);
		
		slider.setMinimum(50);
		slider.setMaximum(200);
		slider.setValue(125);

		panel_1.setLeftComponent(slider);
		frame.setJMenuBar(menuBar);
		menuBar.add(mnFile);
		mnFile.add(mntmOpen);
		
		mntmOpen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				SwingWorker<Boolean, Integer> worker = new SwingWorker<Boolean, Integer>() {

					@Override
					protected Boolean doInBackground() throws Exception {
						// TODO Auto-generated method stub
						int result;
						String choosertitle = null;

						JFileChooser chooser = new JFileChooser();
						chooser.setCurrentDirectory(new java.io.File("."));
						chooser.setDialogTitle(choosertitle);
						chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
						chooser.setAcceptAllFileFilterUsed(false);
						//
						if (chooser.showOpenDialog(menuBar) == JFileChooser.APPROVE_OPTION) {

							locationField.setText(chooser.getSelectedFile()
									.toString());

							fileDetailsTextArea.setEditable(false);
							fileSystemModel = new FileSystemModel(new File(
									chooser.getSelectedFile().toString()));
							tree = new JTree(fileSystemModel);
							tree.setEditable(true);
							tree.addTreeSelectionListener(new TreeSelectionListener() {
								public void valueChanged(
										TreeSelectionEvent event) {

									Object object = event.getPath().getLastPathComponent();
									if (object instanceof File) {
										File file = (File) object;

										if (file.toString().toLowerCase().endsWith(".jpg")|| file.toString().toLowerCase().endsWith(".png")) {
											BufferedImage image = null;
											try {
												image = ImageIO.read(file);
											} catch (Exception e1) {
												e1.printStackTrace();
												System.exit(1);
											}

											ImageIcon imageIcon = new ImageIcon(image);
											Image images = imageIcon.getImage(); // transform
																					// it
											Image newimg = images.getScaledInstance(100,100,java.awt.Image.SCALE_SMOOTH);

											imageIcon = new ImageIcon(newimg);
											preview.setIcon(imageIcon);

											frame.getContentPane().add(panel_1,"center,grow");

											tree.addMouseListener(new MouseAdapter() {
												public void mouseClicked(
														MouseEvent e) {
													if (e.getClickCount() == 2) {

														BufferedImage image = null;
														try {
															image = ImageIO.read(file);
															BufferedImage img = ImageIO.read(file);
															int width = img.getWidth();
															int height = img.getHeight();
															ImageIcon icon = new ImageIcon(img);
															Image images = icon.getImage();
															Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
															int screenWidth = (int) screenSize.getWidth();
															int screenHeight = (int) screenSize.getHeight();
															

															int newWidth;
															int newHight;
															if (width > screenWidth|| height > screenHeight) {

																if (height > screenHeight&& width < screenWidth) {

																	Image newimg = images.getScaledInstance(width,screenHeight - 100,java.awt.Image.SCALE_SMOOTH);
																	icon = new ImageIcon(newimg); 
																						
																} else if (height < screenHeight&& width > screenWidth) {

																	Image newimg = images.getScaledInstance(screenWidth - 100,height,java.awt.Image.SCALE_SMOOTH);
																	icon = new ImageIcon(newimg); 
																						
																} 
																else 
																{
																	Image newimg = images.getScaledInstance(screenWidth - 100,screenHeight - 100,java.awt.Image.SCALE_SMOOTH);
																	icon = new ImageIcon(newimg); 					
																}
															} else {
																Image newimg = images.getScaledInstance(width,height,java.awt.Image.SCALE_SMOOTH);												
																icon = new ImageIcon(newimg); 
																					
															}

															JFrame frame2 = new JFrame();
															frame2.getContentPane().setLayout(new MigLayout());
															JLabel lbl = new JLabel();
															lbl.setIcon(icon);
															frame2.getContentPane().add(lbl);
															frame2.setSize(frame2.getPreferredSize());
															progressBar.setValue(100);
															progressBar.setStringPainted(true);
															frame2.validate();
															frame2.repaint();
															frame2.setVisible(true);

														} catch (Exception e1) {
															e1.printStackTrace();
															System.exit(1);
														}
													}
												}
											});

										}
									}

								}

							});

							scrollPanenew.setViewportView(tree);

						} else {
							System.out.println("No Selection");
						}
						return null;
					}

				};
				worker.execute();
			}
		});
	
		mnFile.add(mntmClear);

		mnFile.add(mntmOpenWith);

		mnFile.add(mntmCopy);

		mnFile.add(mntmProperties);

		menuBar.add(mnView);

		mnView.add(mntmResolution);
		
		mnView.add(mntmZoomIn);
		
		mnView.add(mntmZoomOut);
		
		mnView.add(mntmFullScreen);

		menuBar.add(mnNewMenu);

		mnNewMenu.add(mntmEmail);

		menuBar.add(mnHelp);

		menuBar.add(mnTag);

		mnTag.add(mntmNewMenuItem);

		mnTag.add(mntmOrderPrints);

		menuBar.add(mnFavourites);
		
		mnFavourites.add(mntmOpenFavourites);

		menuBar.add(mnCreate);

		mnCreate.add(mntmPlaySlideShow);

		menuBar.add(mnTools);
		
		mnTools.add(mntmSelect);
		mntmClear.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				preview.setIcon(null);
				progressBar.setValue(0);
				frame2.dispose();
			}
		});
		JPanel panel = new JPanel();
		frame.setVisible(true);

	}

	public static void TreeDisplay(String directory) {

		fileDetailsTextArea.setEditable(false);
		fileSystemModel = new FileSystemModel(new File(directory));
		tree = new JTree(fileSystemModel);
		tree.setEditable(true);
		tree.addTreeSelectionListener(new TreeSelectionListener() {
			public void valueChanged(TreeSelectionEvent event) {
				File file = (File) tree.getLastSelectedPathComponent();
				fileDetailsTextArea.setText(getFileDetails(file));
			}
		});
		JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
				true, new JScrollPane(tree), new JScrollPane(
						fileDetailsTextArea));

	}

	private static String getFileDetails(File file) {
		if (file == null)
			return "";
		StringBuffer buffer = new StringBuffer();
		buffer.append("Name: " + file.getName() + "\n");
		buffer.append("Path: " + file.getPath() + "\n");
		buffer.append("Size: " + file.length() + "\n");
		return buffer.toString();
	}

	public static void errorMsg(String errorMsg, String titleBar) {
		JOptionPane.showMessageDialog(null, errorMsg, titleBar,
				JOptionPane.INFORMATION_MESSAGE);
	}

}

class FileSystemModel implements TreeModel {
	private File root;

	private Vector listeners = new Vector();

	public FileSystemModel(File rootDirectory) {
		root = rootDirectory;
	}

	public Object getRoot() {
		return root;
	}

	public Object getChild(Object parent, int index) {
		File directory = (File) parent;
		String[] children = directory.list();
		return new TreeFile(directory, children[index]);
	}

	public int getChildCount(Object parent) {
		File file = (File) parent;
		if (file.isDirectory()) {
			String[] fileList = file.list();
			if (fileList != null)
				return file.list().length;
		}
		return 0;
	}

	public boolean isLeaf(Object node) {
		File file = (File) node;
		return file.isFile();
	}

	public int getIndexOfChild(Object parent, Object child) {
		File directory = (File) parent;
		File file = (File) child;
		String[] children = directory.list();
		for (int i = 0; i < children.length; i++) {
			if (file.getName().equals(children[i])) {
				return i;
			}
		}
		return -1;

	}

	public void valueForPathChanged(TreePath path, Object value) {
		File oldFile = (File) path.getLastPathComponent();
		String fileParentPath = oldFile.getParent();
		String newFileName = (String) value;
		File targetFile = new File(fileParentPath, newFileName);
		oldFile.renameTo(targetFile);
		File parent = new File(fileParentPath);
		int[] changedChildrenIndices = { getIndexOfChild(parent, targetFile) };
		Object[] changedChildren = { targetFile };
		fireTreeNodesChanged(path.getParentPath(), changedChildrenIndices,
				changedChildren);

	}

	private void fireTreeNodesChanged(TreePath parentPath, int[] indices,
			Object[] children) {
		TreeModelEvent event = new TreeModelEvent(this, parentPath, indices,
				children);
		Iterator iterator = listeners.iterator();
		TreeModelListener listener = null;
		while (iterator.hasNext()) {
			listener = (TreeModelListener) iterator.next();
			listener.treeNodesChanged(event);
		}
	}

	public void addTreeModelListener(TreeModelListener listener) {
		listeners.add(listener);
	}

	public void removeTreeModelListener(TreeModelListener listener) {
		listeners.remove(listener);
	}

	private class TreeFile extends File {
		public TreeFile(File parent, String child) {
			super(parent, child);
		}

		public String toString() {
			return getName();
		}
	}

}
